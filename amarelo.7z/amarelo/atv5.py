# 5-Faça um Programa que converta metros para centímetros.

print("Metros em Centímetros")

metros = float(input("Digite um valor: "))

resultado = metros / 100

print("Resultado em centímetros: ", resultado)