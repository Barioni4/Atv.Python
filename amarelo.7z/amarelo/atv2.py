#   2-Faça um Programa que peça um número e então mostre a mensagem O número informado foi [número].

num = input("Digite um número: ");
print ("O número escolhido foi: " , num)