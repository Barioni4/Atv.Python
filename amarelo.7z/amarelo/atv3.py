# 3-Faça um Programa que peça dois números e imprima a soma.

num = float(input("Digite seu número favorito: "));

num2 = float(input("Digite o número que menos gosta: "));

soma = num + num2

# Resultado

print("O resultado da soma dos dois números é: ", soma)