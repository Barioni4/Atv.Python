# 4-Faça um Programa que peça as 4 notas bimestrais e mostre a média.

bi1 = int(input("Informe a nota do Primeiro Bimestre: "));

bi2 = int(input("Informe a nota do Segundo Bimestre: "));

bi3 = int(input("Informe a nota do Terceiro Bimestre: "));

bi4 = int(input("Informe a nota do Quarto Bimestre: "));

soma = bi1 + bi2 + bi3 + bi4; 

media = soma/4; 

print("Sua média é: ", media)